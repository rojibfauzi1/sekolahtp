
<h2>Selamat datang <?php echo $user ?></h2>