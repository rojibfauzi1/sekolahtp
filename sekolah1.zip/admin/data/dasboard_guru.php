
<h2>Selamat datang <?php echo $guru ?></h2>