<!DOCTYPE html>

<html lang="id">
<head>
<title>SDN 17 Tanjung Pandan</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" type="text/css" href="asset/DataTables/DataTables-1/css/jquery.dataTables.css">
	
		<script type="text/javascript" src="asset/js/jquery-2.1.1.min.js"></script>
	<script type="text/javascript" src="asset/DataTables/DataTables-1/js/jquery.dataTables.js"></script>
	<script type="text/javascript" src="asset/js/bootstrap.min.js"></script>
	<script type="text/javascript">
	$(document).ready(function(){
    	$('#table').DataTable();
	});
	</script>

	
</head>
